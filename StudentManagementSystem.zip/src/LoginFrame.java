import javax.swing.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {
    JTextField userField;
    JPasswordField passField;

    public LoginFrame() {
        setTitle("Login - Student Management System");
        setSize(300, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        userField = new JTextField(15);
        passField = new JPasswordField(15);
        JButton loginBtn = new JButton("Login");

        loginBtn.addActionListener(e -> checkLogin());

        JPanel panel = new JPanel();
        panel.add(new JLabel("Username:"));
        panel.add(userField);
        panel.add(new JLabel("Password:"));
        panel.add(passField);
        panel.add(loginBtn);

        add(panel);
        setVisible(true);
    }

    private void checkLogin() {
        String username = userField.getText();
        String password = new String(passField.getPassword());

        if (username.equals("admin") && password.equals("admin123")) {
            new AdminPanel();
            dispose();
        } else if (username.equals("faculty1") && password.equals("pass123")) {
            new FacultyPanel();
            dispose();
        } else if (username.equals("student1") && password.equals("student123")) {
            new StudentPanel();
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials");
        }
    }
}